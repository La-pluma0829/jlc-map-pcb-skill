# 西湖真实地图数据恢复调查

日期：2026-11-14（上海时间）。本记录仅区分实际请求结果与候选来源；没有成功下载新的地图几何数据。

## 本子任务实际执行结果

1. 搜索西湖 OSM relation、公开 GeoJSON 和官方地图，取得可阅读的来源页，但没有取得可直接用于 PCB 的真实几何文件。
2. `web.open` 读取成功：<https://mapcarta.com/15924540/Map>。页面确认西湖位置与 OpenStreetMap 来源链接，并提供 Wikidata `Q502371`。这只是说明页，不是边界数据，不可作为几何下载成功证据。
3. `web.open` 请求 <https://nominatim.openstreetmap.org/search?q=West%20Lake%20Hangzhou&format=jsonv2&polygon_geojson=1>，工具返回 URL 不可访问（Internal Error）；没有取得 JSON。
4. 在沙箱中用 `curl --fail --location --connect-timeout 10 --max-time 25 --user-agent JLCMapPCB-skill-selftest/1.0` 请求同一 Nominatim URL，退出码 6：`Could not resolve host: nominatim.openstreetmap.org`。
5. 依规则对该 curl 请求发起 `require_escalated` 重试审批。所在工具调用约 800.5 秒后被用户中断，未返回可确认的网络响应。本记录不能将审批请求当成实际 HTTP 请求成功，也不能将原计划输出 `nominatim_west_lake.json` 当成有效地图。

## 根任务已记录/通报的其他失败

- `https://overpass-api.de/api/interpreter`：Python 请求 SSL 握手失败，详见同目录 `download_manifest.json`。
- `https://overpass.kumi.systems/api/interpreter`：读取超时，同上。
- `https://overpass.private.coffee/api/interpreter`：读取超时，同上。
- `https://api.openstreetmap.org/api/0.6/map?bbox=120.12,30.22,120.165,30.265`：根任务通报 curl HTTP 503。
- `https://lz4.overpass-api.de/api/interpreter`：根任务通报 curl GET HTTP 406。旧日志有 User-Agent 兼容性线索，但本子任务未实际执行 POST 重试，不能写成已验证恢复方法。

## 已找到但未下载的候选资料

- 联合国教科文组织西湖地图页：<https://whc.unesco.org/en/list/1334/maps/>。提供遗产范围地图，不能自动等同湖岸水体边界。
- 西湖博物馆官方介绍：<https://www.westlakemuseum.com/index.php/bwggk/bwgjj-en.html>。可作地方特点的研究来源，不是矢量数据。
- Nominatim 带 `polygon_geojson=1` 的请求若之后恢复网络，可尝试返回真实边界；返回前必须核对对象是湖体还是景区/行政区域，且核对数据来源及适用许可。

## 当前结论与恢复路径

本次新联网地图下载仍未完成；不可用推测坐标、渲染图或历史示意图冒充真实抓取成果。可由用户稍后导出 OSM XML/GeoJSON 后按既定 pipeline 继续；或者在网络恢复后对上述公开端点进行有界重试。若使用已有缓存做回归，应单独标明缓存来源、日期和范围，并将“首次联网抓取”验收项保留为未通过。

OpenStreetMap 数据适用来源标注：© OpenStreetMap contributors，ODbL；许可说明 <https://www.openstreetmap.org/copyright>。本记录本身没有收到新的 OSM 几何内容。
