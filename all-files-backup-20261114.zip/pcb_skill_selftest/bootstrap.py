"""Fixed-scope setup: fetch public West Lake OSM and install the prepared skill.

Network destinations and output directory are intentionally fixed for this run.
Rerunning preserves downloaded raw data and refuses to replace an existing skill.
"""
from pathlib import Path
import datetime, hashlib, json, shutil, urllib.request, urllib.parse, time

ROOT = Path(__file__).resolve().parent
STAGED = ROOT.parent / 'skill_build' / 'jlc-map-pcb'
DEST = Path('/Users/goldenstar/.codex/skills/jlc-map-pcb')
QUERY = '''[out:xml][timeout:50];(way["natural"="water"](30.220,120.120,30.265,120.165);relation["natural"="water"](30.220,120.120,30.265,120.165);way["waterway"](30.220,120.120,30.265,120.165);way["highway"](30.220,120.120,30.265,120.165););(._;>;);out body;'''
ENDPOINTS = ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter', 'https://overpass.private.coffee/api/interpreter']

def main():
    raw = ROOT / '03_raw_map'; raw.mkdir(exist_ok=True)
    (raw / 'request.overpassql').write_text(QUERY)
    target = raw / 'west_lake.osm'
    attempts = []
    if not target.exists():
        for endpoint in ENDPOINTS:
            try:
                req = urllib.request.Request(endpoint, data=urllib.parse.urlencode({'data': QUERY}).encode(), headers={'User-Agent': 'JLC-map-PCB-skill-selftest/1.0', 'Content-Type': 'application/x-www-form-urlencoded'})
                with urllib.request.urlopen(req, timeout=60) as response: data = response.read()
                if b'<osm' not in data or b'<remark>' in data: raise ValueError('OSM download absent or server remark')
                target.write_bytes(data)
                attempts.append({'endpoint': endpoint, 'ok': True, 'bytes': len(data)})
                break
            except Exception as exc:
                attempts.append({'endpoint': endpoint, 'ok': False, 'error': str(exc)})
    report = {'retrieved_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'bbox_wsen':[120.120,30.220,120.165,30.265], 'license':'OpenStreetMap ODbL, © OpenStreetMap contributors', 'license_url':'https://www.openstreetmap.org/copyright', 'attempts':attempts}
    if target.exists(): report['sha256'] = hashlib.sha256(target.read_bytes()).hexdigest()
    (raw / 'download_manifest.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    if not (STAGED / 'SKILL.md').is_file(): raise RuntimeError('Prepared SKILL.md missing; not installing')
    if DEST.exists():
        print('Existing install preserved:', DEST)
    else:
        shutil.copytree(STAGED, DEST)
        print('Skill installed:', DEST)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not target.exists(): raise RuntimeError('All map endpoints failed; see manifest')

if __name__ == '__main__': main()
