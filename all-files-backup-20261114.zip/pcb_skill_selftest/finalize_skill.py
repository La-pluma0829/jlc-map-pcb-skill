"""Back up the installed V1 then sync only this task's reviewed skill files."""
from pathlib import Path
import json,hashlib,shutil,zipfile,subprocess,re

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'skill_build'/'jlc-map-pcb'
INSTALLED=Path('/Users/goldenstar/.codex/skills/jlc-map-pcb')

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    validation={}
    official=subprocess.run(['python3','/Users/goldenstar/.codex/skills/.system/skill-creator/scripts/quick_validate.py',str(SOURCE)],text=True,capture_output=True)
    validation['official_validator']={'exit_code':official.returncode,'stdout':official.stdout,'stderr':official.stderr}
    ruby='p=ARGV[0]; s=File.read(p); f=s.split("---",3)[1]; puts JSON.generate(YAML.safe_load(f))'
    front=json.loads(subprocess.check_output(['ruby','-r','yaml','-r','json','-e',ruby,str(SOURCE/'SKILL.md')],text=True))
    assert front['name']=='jlc-map-pcb'
    assert re.fullmatch(r'[a-z0-9-]{1,64}',front['name'])
    assert isinstance(front['description'],str) and 0<len(front['description'])<1024
    assert set(front)<={'name','description','license','allowed-tools','metadata','compatibility'}
    body=(SOURCE/'SKILL.md').read_text()
    links=re.findall(r'\]\(([^)]+)\)',body)
    for target in links:
        if not target.startswith(('http:','https:','#')):assert (SOURCE/target).is_file(),target
    ui=json.loads(subprocess.check_output(['ruby','-r','yaml','-r','json','-e','puts JSON.generate(YAML.safe_load(File.read(ARGV[0])))',str(SOURCE/'agents/openai.yaml')],text=True))
    assert '$jlc-map-pcb' in ui['interface']['default_prompt']
    assert 25<=len(ui['interface']['short_description'])<=64
    validation['ruby_yaml_and_schema']={'status':'PASS','references':links,'checks':['frontmatter keys','name','description','referenced files','UI YAML','invocation name']}
    (ROOT/'07_review/skill_validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2))
    backup=ROOT/'00_skill_v1/installed_before_v1_1.zip'
    if not backup.exists():
        with zipfile.ZipFile(backup,'x',zipfile.ZIP_DEFLATED) as z:
            for p in sorted(INSTALLED.rglob('*')):
                if p.is_file():z.write(p,'jlc-map-pcb/'+str(p.relative_to(INSTALLED)))
    current=ROOT/'08_skill_current'/'jlc-map-pcb'
    shutil.copytree(SOURCE,current,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    shutil.copytree(SOURCE,INSTALLED,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    rows=[]
    for p in sorted(current.rglob('*')):
        if p.is_file():
            rel=p.relative_to(current);assert digest(p)==digest(INSTALLED/rel)
            rows.append({'path':str(rel),'sha256':digest(p)})
    (ROOT/'08_skill_current/install_check.json').write_text(json.dumps({'installed':str(INSTALLED),'status':'IDENTICAL','files':rows},ensure_ascii=False,indent=2))
    shutil.copy2(ROOT.parent/'github_pcb_backup'/'01_香港维多利亚港.epro2',ROOT/'03_raw_map/template_维港_只读副本.epro2')
    print(json.dumps({'installed':str(INSTALLED),'backed_up':str(backup),'files_synced':len(rows),'yaml_schema':'PASS','official_validator_exit':official.returncode},ensure_ascii=False))

if __name__=='__main__':main()
