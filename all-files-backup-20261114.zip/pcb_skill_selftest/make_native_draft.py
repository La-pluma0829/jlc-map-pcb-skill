#!/usr/bin/env python3
"""Build an isolated editable EPRO2 map draft; EDA import is still required.

Native internal coordinates are mil, x right/y up. Placement inputs are mm
measured right/down from the board's upper-left corner. No source is modified.
"""
import argparse
import collections
import copy
import hashlib
import json
import math
from pathlib import Path
import time
import uuid
import zipfile

MIL_PER_MM = 1 / 0.0254


def read_documents(archive):
    with zipfile.ZipFile(archive) as z:
        names = [n for n in z.namelist() if n.endswith('.epru')]
        if len(names) != 1:
            raise ValueError('Expected one native EPRU record stream')
        source = z.read(names[0]).decode('utf-8')
        project = json.loads(z.read('project2.json'))
    docs, current = [], None
    decoder = json.JSONDecoder()
    for line in source.splitlines():
        header_text, body_text = line.split('||', 1)
        header = json.loads(header_text)
        if header['type'] == 'DOCHEAD':
            body = decoder.raw_decode(body_text)[0]
            current = {'head': body, 'records': []}
            docs.append(current)
        elif current and current['head']['docType'] in {'BOARD', 'PCB'}:
            # Empty bodies are deletion records and are deliberately discarded.
            if not body_text or body_text == '|':
                continue
            body = decoder.raw_decode(body_text)[0]
            current['records'].append((header, body))
    return project, docs


def read_dxf(path):
    lines = path.read_text().splitlines()
    if len(lines) % 2:
        raise ValueError('Unbalanced DXF group codes')
    pairs = list(zip(lines[::2], lines[1::2]))
    units = next((pairs[i+1][1] for i, pair in enumerate(pairs)
                  if pair == ('9', '$INSUNITS')), None)
    if units != '4':
        raise ValueError('Input DXF must explicitly declare millimetres ($INSUNITS=4)')
    features = []
    for i, pair in enumerate(pairs):
        if pair != ('0', 'LWPOLYLINE'):
            continue
        end = next((j for j in range(i+1, len(pairs)) if pairs[j][0] == '0'), len(pairs))
        entity = pairs[i+1:end]
        if any(k == '42' and float(v) != 0 for k, v in entity):
            raise ValueError('Bulged polylines require a separate arc conversion')
        xs = [float(v) for k, v in entity if k == '10']
        ys = [float(v) for k, v in entity if k == '20']
        count = int(next(v for k, v in entity if k == '90'))
        if len(xs) != count or len(ys) != count or count < 2:
            raise ValueError('Invalid DXF polyline vertices')
        if not all(math.isfinite(v) for v in xs+ys):
            raise ValueError('Nonfinite input coordinates')
        features.append({'points': list(zip(xs, ys)),
                         'closed': bool(int(next((v for k, v in entity if k == '70'), '0')) & 1),
                         'source_layer': next((v for k, v in entity if k == '8'), '')})
    if not features:
        raise ValueError('No LWPOLYLINE map geometry found')
    return features


def make_path(points, closed=False):
    points = list(points)
    if closed and points[-1] != points[0]:
        points.append(points[0])
    # This exact multi-vertex form and repeated-start closure are present in
    # the historical five-dadao native archive. No unverified Z command is used.
    return [*points[0], 'L', *(value for point in points[1:] for value in point)]


def native_poly(points, layer, width, board_outline=False, closed=False):
    return {'partitionId': '', 'groupId': 0, 'netName': '', 'layerId': layer,
            'width': width, 'path': make_path(points, closed), 'locked': False,
            'zIndex': -1, 'polyType': 'BOARD_OUTLINE' if board_outline else 'NORMAL'}


def encode_records(records):
    return '\n'.join(json.dumps(h, ensure_ascii=False, separators=(',', ':')) + '||' +
                     json.dumps(b, ensure_ascii=False, separators=(',', ':')) + '|'
                     for h, b in records) + '\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--template', type=Path, default=Path('outputs/github_pcb_backup/01_香港维多利亚港.epro2'))
    parser.add_argument('--input', type=Path, default=Path('outputs/pcb_skill_selftest/04_assets/regression_wudadao_v1_1.dxf'))
    parser.add_argument('--output', type=Path, default=Path('outputs/pcb_skill_selftest/05_eda/五大道缓存地图_自测草稿_待EDA验证.epro2'))
    parser.add_argument('--title', default='五大道缓存地图_自测草稿_待EDA验证')
    parser.add_argument('--center-mm', type=float, nargs=2, default=(26.5, 27.0))
    parser.add_argument('--stroke-mm', type=float, default=0.2)
    args = parser.parse_args()
    if args.output.exists() or args.output.with_suffix('.static-checks.json').exists():
        parser.error('Refusing to overwrite an existing output or static-check report')
    if args.stroke_mm <= 0 or not all(math.isfinite(v) for v in (*args.center_mm, args.stroke_mm)):
        parser.error('Placement and stroke must be finite, with positive stroke')
    project, docs = read_documents(args.template)
    pcb = next(d for d in docs if d['head']['docType'] == 'PCB')
    features = read_dxf(args.input)
    board_id, pcb_id, client_id = (uuid.uuid4().hex[:16] for _ in range(3))
    timestamp = int(time.time()*1000)
    output_records = []
    tickets = collections.Counter()

    def add(docid, kind, body, ident=None):
        tickets[docid] += 1
        header = {'type': kind, 'ticket': tickets[docid]}
        if ident is not None:
            header['id'] = ident
        output_records.append((header, body))

    def begin(kind, docid):
        add(docid, 'DOCHEAD', {'docType': kind, 'client': client_id, 'uuid': docid,
                             'updateTime': timestamp, 'version': str(timestamp),
                             'editVersion': pcb['head'].get('editVersion', '4.1.60'),
                             'user': {'uuid': docid}})

    begin('BOARD', board_id)
    add(board_id, 'META', {'title': args.title, 'zIndex': 1}, 'META')
    begin('PCB', pcb_id)
    add(pcb_id, 'META', {'title': args.title, 'parent': '', 'source': '',
                       'board': board_id, 'zIndex': None}, 'META')
    keep = {'CANVAS', 'LAYER', 'LAYER_PHYS', 'PRIMITIVE', 'RULE_TEMPLATE',
            'RULE', 'SILK_OPTS', 'PREFERENCE', 'PANELIZE'}
    for header, original_body in pcb['records']:
        if header['type'] not in keep:
            continue
        body = copy.deepcopy(original_body)
        if header['type'] == 'CANVAS':
            body.update(originX=0, originY=0, unit='mil')
        elif header['type'] == 'LAYER':
            body['locked'] = False
            if body['layerId'] in {3, 11}:
                body.update(use=True, show=True)
        elif header['type'] == 'PANELIZE':
            body['on'] = False
        add(pcb_id, header['type'], body, header.get('id'))
    add(pcb_id, 'ACTIVE_LAYER', {'layerId': 3}, 'ACTIVE_LAYER')
    width_mil, height_mil = 85.6*MIL_PER_MM, 54*MIL_PER_MM
    board_points = [(0., 0.), (width_mil, 0.), (width_mil, -height_mil), (0., -height_mil)]
    add(pcb_id, 'POLY', native_poly(board_points, 11, 0.1*MIL_PER_MM, True, True), uuid.uuid4().hex[:16])
    source_points = [p for f in features for p in f['points']]
    source_bounds = [min(p[0] for p in source_points), min(p[1] for p in source_points),
                     max(p[0] for p in source_points), max(p[1] for p in source_points)]
    sx, sy = (source_bounds[0]+source_bounds[2])/2, (source_bounds[1]+source_bounds[3])/2
    cx, cy = args.center_mm
    for feature in features:
        points = [((x-sx+cx)*MIL_PER_MM, (y-sy-cy)*MIL_PER_MM) for x, y in feature['points']]
        add(pcb_id, 'POLY', native_poly(points, 3, args.stroke_mm*MIL_PER_MM,
                                      closed=feature['closed']), uuid.uuid4().hex[:16])
    project.update(title=args.title, editorVersion=pcb['head'].get('editVersion', '4.1.60'),
                   introduction='', description='Isolated native map draft; verify in EDA before use.',
                   custom_tags='[]')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, 'x', zipfile.ZIP_DEFLATED) as z:
        z.writestr('project2.json', json.dumps(project, ensure_ascii=False, indent=2))
        z.writestr(args.title+'.epru', encode_records(output_records))
    # Read the bytes we actually wrote, checking links and every native vertex.
    saved_project, saved_docs = read_documents(args.output)
    assert [d['head']['docType'] for d in saved_docs] == ['BOARD', 'PCB']
    saved_pcb = saved_docs[1]
    meta = next(b for h, b in saved_pcb['records'] if h['type'] == 'META')
    assert meta['board'] == saved_docs[0]['head']['uuid'] == board_id
    polys = [b for h, b in saved_pcb['records'] if h['type'] == 'POLY']
    assert len(polys) == len(features)+1
    assert collections.Counter(p['layerId'] for p in polys) == {11: 1, 3: len(features)}
    assert not any(h['type'] in {'STRING', 'COMPONENT', 'LINE', 'PAD', 'VIA', 'OBJ', 'NET'}
                   for d in saved_docs for h, b in d['records'])
    native_points = []
    for poly in polys[1:]:
        path = poly['path']
        assert path[2] == 'L'
        values = path[:2]+path[3:]
        assert len(values) % 2 == 0 and all(math.isfinite(v) for v in values)
        native_points.extend(zip(values[::2], values[1::2]))
    bounds = [min(x for x,y in native_points)/MIL_PER_MM,
              -max(y for x,y in native_points)/MIL_PER_MM,
              max(x for x,y in native_points)/MIL_PER_MM,
              -min(y for x,y in native_points)/MIL_PER_MM]
    half = args.stroke_mm/2
    ink = [bounds[0]-half, bounds[1]-half, bounds[2]+half, bounds[3]+half]
    fits = ink[0] >= 5-1e-8 and ink[1] >= 5-1e-8 and ink[2] <= 48+1e-8 and ink[3] <= 49+1e-8
    if not fits:
        raise ValueError('Draft was written, but map ink does not fit the required43x44mm placement box')
    report = {'status': 'DRAFT_STATIC_CHECKS_PASS_EDA_IMPORT_UNVERIFIED',
              'output': str(args.output.resolve()), 'output_sha256': hashlib.sha256(args.output.read_bytes()).hexdigest(),
              'input_dxf': str(args.input.resolve()), 'input_dxf_sha256': hashlib.sha256(args.input.read_bytes()).hexdigest(),
              'template': str(args.template.resolve()), 'project_title': saved_project['title'],
              'documents': [{'type': d['head']['docType'], 'uuid': d['head']['uuid']} for d in saved_docs],
              'internal_units': 'mil, x right/y up; board normalized coordinates x right/y down from upper-left',
              'board_size_mm': [85.6, 54], 'map_layer': {'id': 3, 'name': 'Top Silkscreen Layer'},
              'map_entity_count': len(features), 'map_stroke_mm': args.stroke_mm,
              'map_centerline_bbox_normalized_mm': bounds, 'map_ink_bbox_normalized_mm': ink,
              'map_center_normalized_mm': [cx, cy], 'target_box_normalized_mm': [5, 5, 48, 49],
              'fits_target_box': fits, 'old_drawings_text_electric_parts': 'removed',
              'closure': 'repeat first coordinate; verified native multi-vertex format',
              'checks': ['archive readback', 'BOARD-PCB metadata links', 'fresh document UUIDs',
                         'unit conversion', 'layer/entity counts', 'finite vertex coordinates',
                         'target box including stroke', 'no unrelated artwork or components'],
              'limitations': ['Not yet imported, visually checked, saved, or reopened in EDA.',
                              'No native DRC, Gerber verification, production review or physical test.']}
    args.output.with_suffix('.static-checks.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
