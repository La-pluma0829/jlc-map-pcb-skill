"""Render factual SVG polylines into a labelled PCB data preview with Pillow."""
from pathlib import Path
import xml.etree.ElementTree as ET
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
source=ROOT/'04_assets/regression_wudadao_v1_1.svg'
im=Image.new('RGB',(1800,1260),'#e7eaed'); d=ImageDraw.Draw(im)
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',28)
small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',23)
scale=18; ox,oy=130,145
p=lambda x,y:(ox+x*scale,oy+y*scale)
d.rounded_rectangle((*p(0,0),*p(85.6,54)),radius=35,fill='#fafafa',outline='#9ca8ac',width=3)
d.rectangle((*p(5,5),*p(48,49)),outline='#d6dde0',width=2)
root=ET.parse(source).getroot()
for element in root.iter():
 if element.tag.rsplit('}',1)[-1] not in {'polyline','polygon'}:continue
 points=[tuple(map(float,v.split(','))) for v in element.attrib['points'].split()]
 points=[p(26.5+x,27-y) for x,y in points]
 if element.tag.endswith('polygon'):points.append(points[0])
 d.line(points,fill='#182125',width=4,joint='curve')
d.text(p(53,13),'WUDADAO',fill='#17242c',font=font)
d.text(p(53,17),'CACHED MAP TEST',fill='#64747e',font=small)
d.text(p(53,24),'Top silk / 0.2 mm',fill='#64747e',font=small)
d.text(p(53,28),'85.6 x 54 mm board',fill='#64747e',font=small)
d.text(p(53,32),'43 x 44 mm map box',fill='#64747e',font=small)
d.text((130,1160),'Programmatic data preview / cached real OSM / EDA import remains unverified',fill='#455963',font=small)
d.text((130,1200),'Map data: (c) OpenStreetMap contributors, ODbL. Target box and labels are preview annotations.',fill='#455963',font=small)
im.save(ROOT/'04_assets/五大道缓存地图_程序预览_非EDA截图.png')
