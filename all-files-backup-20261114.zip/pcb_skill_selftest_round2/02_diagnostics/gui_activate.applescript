with timeout of 10 seconds
    tell application "/private/var/folders/rz/4szxt8fd2pd85q0h8wr6zrz40000gn/T/AppTranslocation/E1172A60-BE2B-42D2-A8C8-AFA00EAC99DA/d/jlc-assistant.app" to activate
    delay 1
    tell application "System Events"
        tell process "jlc-assistant"
            set frontmost to true
            delay 1
            set n to count of windows
            if n = 0 then return {name, unix id, frontmost, n}
            return {name, unix id, frontmost, n, name of window 1, position of window 1, size of window 1}
        end tell
    end tell
end timeout
