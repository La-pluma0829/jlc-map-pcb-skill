with timeout of 8 seconds
    tell application "System Events"
        set enabledFlag to UI elements enabled
        set processNames to name of application processes whose name contains "jlc"
        if (count processNames) is 0 then return {enabledFlag, "no jlc process"}
        tell process (item 1 of processNames)
            return {enabledFlag, name, visible, frontmost, count of windows, position of window 1, size of window 1}
        end tell
    end tell
end timeout
