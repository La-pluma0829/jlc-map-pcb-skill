with timeout of 8 seconds
    tell application "System Events"
        set outputRows to {}
        repeat with p in (application processes whose name contains "jlc")
            set end of outputRows to {name of p, unix id of p, visible of p, frontmost of p, count of windows of p}
        end repeat
        return outputRows
    end tell
end timeout
