on run argv
    set actionName to item 1 of argv
    tell application "/private/var/folders/rz/4szxt8fd2pd85q0h8wr6zrz40000gn/T/AppTranslocation/E1172A60-BE2B-42D2-A8C8-AFA00EAC99DA/d/jlc-assistant.app" to activate
    delay 0.3
    tell application "System Events"
        tell process "jlc-assistant"
            set frontmost to true
            if actionName is "info" then
                return {position of window 1, size of window 1}
            else if actionName is "click" or actionName is "doubleclick" then
                set wp to position of window 1
                set ws to size of window 1
                set px to (item 2 of argv) as real
                set py to (item 3 of argv) as real
                if px < 0 or py < 0 or px > (item 1 of ws) or py > (item 2 of ws) then error "Click outside selected JLC window refused"
                click at {(item 1 of wp) + px, (item 2 of wp) + py}
                if actionName is "doubleclick" then
                    delay 0.1
                    click at {(item 1 of wp) + px, (item 2 of wp) + py}
                end if
            else if actionName is "key" then
                set keyName to item 2 of argv
                if keyName is "escape" then
                    key code 53
                else if keyName is "return" then
                    key code 36
                else if keyName is "tab" then
                    key code 48
                else if keyName is "open" then
                    keystroke "o" using command down
                else if keyName is "save" then
                    keystroke "s" using command down
                else if keyName is "selectall" then
                    keystroke "a" using command down
                else if keyName is "gopath" then
                    keystroke "g" using {command down, shift down}
                else if keyName is "space" then
                    key code 49
                else
                    error "Unsupported key"
                end if
            else if actionName is "type" then
                set oldClipboard to the clipboard
                set the clipboard to item 2 of argv
                keystroke "v" using command down
                delay 0.15
                set the clipboard to oldClipboard
            else
                error "Unsupported action"
            end if
        end tell
    end tell
end run
