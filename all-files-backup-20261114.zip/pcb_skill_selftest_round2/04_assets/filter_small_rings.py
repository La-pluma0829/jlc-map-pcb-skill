#!/usr/bin/env python3
"""Create a separately named map candidate by omitting tiny island outlines.

This test-specific filter preserves every exterior ring and all retained DXF
coordinates. It does not enlarge gaps or imply manufacturing acceptance.
"""
import argparse
import hashlib
import html
import json
import math
from pathlib import Path


def point_distance(p, a, b):
    dx, dy = b[0]-a[0], b[1]-a[1]
    denominator = dx*dx+dy*dy
    t = max(0, min(1, ((p[0]-a[0])*dx+(p[1]-a[1])*dy)/denominator)) if denominator else 0
    return math.hypot(p[0]-a[0]-t*dx, p[1]-a[1]-t*dy)


def segment_distance(a, b, c, d):
    def cross(p, q, r):
        return (q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
    if cross(a, b, c)*cross(a, b, d) < 0 and cross(c, d, a)*cross(c, d, b) < 0:
        return 0.0
    return min(point_distance(a, c, d), point_distance(b, c, d),
               point_distance(c, a, b), point_distance(d, a, b))


def near_pairs(features, stroke):
    result = []
    for i, feature in enumerate(features):
        a_points = feature['points']+[feature['points'][0]]
        for other in features[i+1:]:
            b_points = other['points']+[other['points'][0]]
            distance = min(segment_distance(a, b, c, d)
                           for a, b in zip(a_points, a_points[1:])
                           for c, d in zip(b_points, b_points[1:]))
            if distance < stroke:
                result.append({'rings': [feature['source_id'], other['source_id']],
                               'centerline_distance_mm': distance,
                               'stroke_overlap_depth_mm': stroke-distance})
    return sorted(result, key=lambda entry: entry['centerline_distance_mm'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-prefix', type=Path, required=True)
    parser.add_argument('--output-prefix', type=Path, required=True)
    parser.add_argument('--min-bbox-mm', type=float, default=0.4)
    parser.add_argument('--stroke-mm', type=float, default=0.2)
    args = parser.parse_args()
    if args.min_bbox_mm <= 0 or args.stroke_mm <= 0:
        parser.error('Threshold and preview stroke must be positive')
    suffixes = ['.dxf', '.svg', '.geojson', '.filter-manifest.json']
    if any(args.output_prefix.with_suffix(s).exists() for s in suffixes):
        parser.error('Refusing to overwrite candidate outputs')
    source_dxf = args.input_prefix.with_suffix('.dxf')
    source_geojson = args.input_prefix.with_suffix('.geojson')
    source_report = args.input_prefix.with_suffix('.report.json')
    lines = source_dxf.read_text().splitlines()
    if len(lines) % 2:
        raise ValueError('Unbalanced DXF tokens')
    pairs = list(zip(lines[::2], lines[1::2]))
    units = next((pairs[i+1][1] for i, p in enumerate(pairs) if p == ('9', '$INSUNITS')), None)
    if units != '4':
        raise ValueError('DXF must explicitly declare millimetres')
    geojson = json.loads(source_geojson.read_text())
    report = json.loads(source_report.read_text())
    features, removals = [], set()
    for i, pair in enumerate(pairs):
        if pair != ('0', 'LWPOLYLINE'):
            continue
        end = next((j for j in range(i+1, len(pairs)) if pairs[j][0] == '0'), len(pairs))
        entity = pairs[i+1:end]
        layer = next(v for k, v in entity if k == '8')
        if layer not in {'Water', 'Water_Islands'}:
            raise ValueError('This filter only accepts Water/Water_Islands outlines')
        closed = int(next(v for k, v in entity if k == '70')) & 1
        if not closed:
            raise ValueError('Expected closed ring polylines')
        points = list(zip([float(v) for k, v in entity if k == '10'],
                          [float(v) for k, v in entity if k == '20']))
        gf = geojson['features'][len(features)]
        if (gf['properties']['layer'] == 'islands') != (layer == 'Water_Islands'):
            raise ValueError('DXF and GeoJSON feature order do not agree')
        width = max(p[0] for p in points)-min(p[0] for p in points)
        height = max(p[1] for p in points)-min(p[1] for p in points)
        omit = layer == 'Water_Islands' and min(width, height) < args.min_bbox_mm
        feature = {'source_id': gf['properties']['source_id'], 'layer': layer,
                   'points': points, 'bbox_size_mm': [width, height], 'omitted': omit}
        features.append(feature)
        if omit:
            removals.update(range(i, end))
    if len(features) != len(geojson['features']):
        raise ValueError('DXF and GeoJSON entity counts do not agree')
    kept = [f for f in features if not f['omitted']]
    original_overlaps = near_pairs(features, args.stroke_mm)
    retained_overlaps = near_pairs(kept, args.stroke_mm)
    args.output_prefix.parent.mkdir(parents=True, exist_ok=True)
    out_dxf = args.output_prefix.with_suffix('.dxf')
    out_dxf.write_text('\n'.join(value for i, pair in enumerate(pairs) if i not in removals for value in pair)+'\n')
    geojson['features'] = [f for f, feature in zip(geojson['features'], features) if not feature['omitted']]
    args.output_prefix.with_suffix('.geojson').write_text(json.dumps(geojson, ensure_ascii=False)+'\n')
    width, height = report['requested_envelope_mm']
    margin = 1.5
    body = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width+2*margin}mm" height="{height+2*margin}mm" viewBox="{-width/2-margin} {-height/2-margin} {width+2*margin} {height+2*margin}">',
            '<rect x="-10000" y="-10000" width="20000" height="20000" fill="white"/>',
            '<g transform="scale(1,-1)" fill="none" stroke="black" stroke-linecap="round" stroke-linejoin="round">']
    for feature in kept:
        coordinates = ' '.join(f'{x:.8f},{y:.8f}' for x, y in feature['points'])
        body.append(f'<polygon points="{coordinates}" stroke-width="{args.stroke_mm}"><title>{html.escape(feature["source_id"])}</title></polygon>')
    body.extend(['</g>', '</svg>'])
    args.output_prefix.with_suffix('.svg').write_text('\n'.join(body)+'\n')
    manifest = {'status': 'FILTERED_CANDIDATE_NOT_MANUFACTURING_APPROVAL',
                'source_files': {str(p.resolve()): hashlib.sha256(p.read_bytes()).hexdigest()
                                 for p in [source_dxf, source_geojson, source_report]},
                'rule': 'Preserve every Water exterior; omit Water_Islands when min(centerline_bbox_width,height) < threshold. No retained coordinates changed.',
                'test_specific_min_bbox_mm': args.min_bbox_mm, 'preview_and_planned_import_stroke_mm': args.stroke_mm,
                'original_ring_count': len(features), 'retained_ring_count': len(kept),
                'omitted_rings': [{k: v for k, v in f.items() if k != 'points'} for f in features if f['omitted']],
                'original_ring_pairs_with_overlapping_strokes': original_overlaps,
                'retained_ring_pairs_with_overlapping_strokes': retained_overlaps,
                'limitations': ['Tiny-ring omission does not resolve every close shore or island pair.',
                                'Remaining stroke overlaps require actual-size visual and manufacturing review.',
                                'Source relation provides shore/island outlines, not an independent road or path dataset.']}
    args.output_prefix.with_suffix('.filter-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({'retained': len(kept), 'omitted': len(features)-len(kept),
                      'retained_overlapping_ring_pairs': len(retained_overlaps),
                      'output_dxf': str(out_dxf.resolve())}, ensure_ascii=False))


if __name__ == '__main__':
    main()
