"""Create a verified local archive while keeping every previous task artifact."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
OUTPUTS = ROOT.parent
ROUND1 = OUTPUTS / 'pcb_skill_selftest'
FIRST_ZIP = OUTPUTS / '嘉立创地图Skill_首轮试跑_完整备份_20261114.zip'
DEST = OUTPUTS / '嘉立创地图Skill_第二轮完成_全部文件备份_20261114.zip'
FIRST_EXPECTED_SHA = '54c2602e485ff830e0a107b21084de6c6b8fc4c9d24424eeb6897ea95c74857a'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert sha(FIRST_ZIP) == FIRST_EXPECTED_SHA, 'First archive was modified'
    with zipfile.ZipFile(FIRST_ZIP) as old:
        assert old.testzip() is None
        for entry in old.infolist():
            if not entry.is_dir():
                original = OUTPUTS / entry.filename
                assert original.is_file(), entry.filename
                assert hashlib.sha256(old.read(entry.filename)).hexdigest() == sha(original), 'First-round file changed: ' + entry.filename
    entries = []
    for folder, prefix in [(ROUND1, ROUND1.name), (ROOT, ROOT.name)]:
        for path in sorted(folder.rglob('*')):
            if path.is_file() and path != ROOT / '99_backup_manifest.json' and '__pycache__' not in path.parts:
                entries.append((path, prefix + '/' + str(path.relative_to(folder))))
    entries.append((FIRST_ZIP, 'preserved_archives/' + FIRST_ZIP.name))
    manifest = {
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'purpose': 'All first-round files, immutable first archive, round2 expected/map/EDA/screenshots/reviews, installed-skill snapshot and previous installation backup',
        'original_first_archive_unchanged': True,
        'original_first_archive_sha256': FIRST_EXPECTED_SHA,
        'file_count_without_manifest': len(entries),
        'files': [{'path': arc, 'bytes': path.stat().st_size, 'sha256': sha(path)} for path, arc in entries],
    }
    manifest_path = ROOT / '99_backup_manifest.json'
    assert not DEST.exists(), 'Refuse to overwrite an existing backup'
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    with zipfile.ZipFile(DEST, 'x', zipfile.ZIP_DEFLATED) as archive:
        for path, arc in entries:
            archive.write(path, arc)
        archive.write(manifest_path, '99_backup_manifest.json')
    with zipfile.ZipFile(DEST) as archive:
        assert archive.testzip() is None
        for row in manifest['files']:
            assert hashlib.sha256(archive.read(row['path'])).hexdigest() == row['sha256'], row['path']
    digest = sha(DEST)
    DEST.with_suffix('.zip.sha256').write_text(digest + '  ' + DEST.name + '\n')
    result = {'archive': str(DEST), 'bytes': DEST.stat().st_size, 'sha256': digest,
              'files_in_zip': len(entries) + 1, 'crc_and_every_payload_sha256': 'PASS',
              'original_first_archive_unchanged': True}
    (OUTPUTS / '嘉立创地图Skill_第二轮完成_备份校验.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
