"""Validate this task's skill, preserve the installed version, then install reviewed files."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
STAGING = ROOT.parent / 'skill_build' / 'jlc-map-pcb'
INSTALLED = Path('/Users/goldenstar/.codex/skills/jlc-map-pcb')
FILES = ['SKILL.md', 'agents/openai.yaml', 'references/eda-map-checks.md', 'scripts/map_to_pcb.py']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate():
    result = subprocess.run(
        ['python3', '/Users/goldenstar/.codex/skills/.system/skill-creator/scripts/quick_validate.py', str(STAGING)],
        text=True, capture_output=True)
    ruby = 's=File.read(ARGV[0]); puts JSON.generate(YAML.safe_load(s.split("---",3)[1]))'
    front = json.loads(subprocess.check_output(
        ['ruby', '-r', 'yaml', '-r', 'json', '-e', ruby, str(STAGING / 'SKILL.md')], text=True))
    assert front['name'] == 'jlc-map-pcb'
    assert re.fullmatch(r'[a-z0-9-]{1,64}', front['name'])
    assert isinstance(front['description'], str) and 0 < len(front['description']) < 1024
    assert set(front) <= {'name', 'description', 'license', 'allowed-tools', 'metadata', 'compatibility'}
    body = (STAGING / 'SKILL.md').read_text()
    links = re.findall(r'\]\(([^)]+)\)', body)
    for link in links:
        if not link.startswith(('http:', 'https:', '#')):
            assert (STAGING / link).is_file(), link
    ui = json.loads(subprocess.check_output(
        ['ruby', '-r', 'yaml', '-r', 'json', '-e', 'puts JSON.generate(YAML.safe_load(File.read(ARGV[0])))', str(STAGING / 'agents/openai.yaml')], text=True))
    assert '$jlc-map-pcb' in ui['interface']['default_prompt']
    assert 25 <= len(ui['interface']['short_description']) <= 64
    for rel in FILES:
        assert (STAGING / rel).is_file()
    report = {
        'official_validator': {'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr},
        'ruby_yaml_schema_and_references': {'status': 'PASS', 'links': links},
        'script_change': 'NONE since round1 corrected and regression-tested map_to_pcb.py',
        'scope': 'Text-only revision from observed round2 data recovery, stroke/readability, window recovery, evidence and preview-color behavior',
    }
    (ROOT / '07_review/skill_validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    return report


def install():
    backup = ROOT / '00_skill_before_round2' / 'installed_before_round2_revision.zip'
    backup.parent.mkdir(exist_ok=True)
    if backup.exists():
        with zipfile.ZipFile(backup) as archive:
            assert archive.testzip() is None
    else:
        with zipfile.ZipFile(backup, 'x', zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(INSTALLED.rglob('*')):
                if path.is_file():
                    archive.write(path, 'jlc-map-pcb/' + str(path.relative_to(INSTALLED)))
    current = ROOT / '08_skill_current/jlc-map-pcb'
    rows = []
    for rel in FILES:
        src = STAGING / rel
        for destination in [current / rel, INSTALLED / rel]:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, destination)
        assert sha(src) == sha(current / rel) == sha(INSTALLED / rel)
        rows.append({'path': rel, 'sha256': sha(src)})
    report = {'status': 'IDENTICAL', 'installed': str(INSTALLED), 'backup': str(backup), 'backup_sha256': sha(backup), 'files': rows}
    (ROOT / '08_skill_current/install_check.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--install', action='store_true')
    args = parser.parse_args()
    report = validate()
    if args.install:
        installed = install()
        print(json.dumps({'validation': report, 'installation': installed}, ensure_ascii=False))
    else:
        print(json.dumps(report, ensure_ascii=False))
