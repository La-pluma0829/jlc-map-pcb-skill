# 第二轮西湖地图恢复：已成功

日期：2026-11-14（Asia/Shanghai）。本轮全部新文件保存在 `outputs/pcb_skill_selftest_round2/`；第一轮证据不变。

## 请求与原始数据

1. Nominatim 精确地名、限定杭州西湖区域、`polygon_geojson=1&limit=1`：HTTP 200，69,541 字节，1.85 秒。原始响应 `attempt1_nominatim.json`，对象为 **relation 2308774，category=water、type=lake、name=西湖**，不是景区或行政界。原始 MultiPolygon 含2个面、35个环、2785个坐标点。
2. 根据该准确对象请求官方 <https://api.openstreetmap.org/api/0.6/relation/2308774/full>：HTTP 200，559,631 字节，3.30 秒。原始响应 `attempt2_west_lake_relation2308774.osm`。XML 解析后含2750节点、62条way、1个relation；节点引用与关系成员均完整，无缺失。

全部请求、响应头、字节数、SHA-256与验证结果见 `round2_download_manifest.json`、`attempt1_validation.json`、`attempt2_validation.json`。提取的 `west_lake_relation2308774.geojson` 保持原始几何坐标不变，仅包装为标准Feature。

## 诊断与可复现方法

本轮诊断未发现 proxy 环境变量；系统 curl 8.7.1 使用 SecureTransport/LibreSSL。使用系统 curl、显式 HTTP/1.1、8秒连接超时、25秒总超时和应用User-Agent，先查单个明确湖体，再从官方对象API下载完整几何。两次请求均成功。此证据不能单独证明第一轮失败的唯一原因，不能概括成某服务永久不可用或强制使用某个代理。

## 真实数据转换回归

直接调用已安装 skill 的 `map_to_pcb.py`，输入官方原始OSM，选 `water` 图层，包住完整湖体范围 `(120.118,30.228,120.159,30.264)`，目标最大43×44mm，保持地理比例。

输出：`processed/west_lake_water.dxf`、`.svg`、`.geojson`、`.report.json`。

- 35个图形实体，1293个简化后顶点。
- 图层计数：{"Water": 2, "Water_Islands": 33}。
- 实际中心线范围：43.000000 × 42.722585mm，符合43×44mm包络。
- DXF序列化回读PASS；未报告缺失节点/关系成员，也未裁剪湖岸闭合边。
- 几何围绕(0,0)居中；在目标板左侧框中落板应另设实际位置。

本批数据包含湖岸和岛岸，不包含独立步道中心线；苏堤等地貌可在水体边界分割中表现，不能把轮廓说成已抓取了步道线网。丝印线宽与制造间距仍需在EDA和制造输出中检查。

数据署名：© OpenStreetMap contributors，ODbL 1.0；<https://www.openstreetmap.org/copyright>。
