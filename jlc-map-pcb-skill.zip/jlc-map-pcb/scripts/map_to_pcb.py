#!/usr/bin/env python3
"""Convert real OSM XML into a size-controlled, layer-labelled PCB map.

Python standard library only. Outputs are map artwork, not electrical nets or a
manufacturing approval. Coordinates in the DXF/SVG are millimetres, centred on 0.
"""

import argparse
import collections
import hashlib
import html
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET


PATH_TYPES = {"footway", "path", "pedestrian", "steps", "cycleway", "bridleway", "track"}
LAYER_NAMES = {"water": "Water", "islands": "Water_Islands", "roads": "Roads", "paths": "Paths"}
EPS = 1e-9


def tags(element):
    return {t.attrib["k"]: t.attrib["v"] for t in element.findall("tag")}


def is_water(t):
    return (t.get("natural") == "water" or t.get("water") in
            {"lake", "pond", "reservoir", "basin", "river", "lagoon"} or
            t.get("landuse") == "reservoir" or t.get("waterway") == "riverbank")


def dedupe(points):
    out = []
    for p in points:
        if not out or math.dist(p, out[-1]) > EPS:
            out.append(p)
    return out


def clip_segment(a, b, box):
    """Liang-Barsky clipping, preserving segments that cross the whole box."""
    xmin, ymin, xmax, ymax = box
    dx, dy = b[0] - a[0], b[1] - a[1]
    lo, hi = 0.0, 1.0
    for p, q in ((-dx, a[0]-xmin), (dx, xmax-a[0]),
                 (-dy, a[1]-ymin), (dy, ymax-a[1])):
        if abs(p) < EPS:
            if q < -EPS:
                return None
        else:
            r = q / p
            if p < 0:
                lo = max(lo, r)
            else:
                hi = min(hi, r)
            if lo > hi + EPS:
                return None
    result = ((a[0]+lo*dx, a[1]+lo*dy), (a[0]+hi*dx, a[1]+hi*dy))
    return result if math.dist(*result) > EPS else None


def clip_line(points, box):
    parts, current = [], []
    for a, b in zip(points, points[1:]):
        clipped = clip_segment(a, b, box)
        if clipped is None:
            if len(current) >= 2:
                parts.append(dedupe(current))
            current = []
        elif current and math.dist(current[-1], clipped[0]) < EPS:
            current.append(clipped[1])
        else:
            if len(current) >= 2:
                parts.append(dedupe(current))
            current = list(clipped)
    if len(current) >= 2:
        parts.append(dedupe(current))
    return [p for p in parts if len(p) >= 2]


def clip_polygon(points, box):
    """Sutherland-Hodgman ring clipping; holes remain separate named rings."""
    points = dedupe(points)
    if points and math.dist(points[0], points[-1]) < EPS:
        points = points[:-1]
    xmin, ymin, xmax, ymax = box
    for axis, value, sign in ((0, xmin, 1), (0, xmax, -1), (1, ymin, 1), (1, ymax, -1)):
        if not points:
            break
        result = []
        previous = points[-1]
        prev_inside = sign * (previous[axis]-value) >= -EPS
        for point in points:
            inside = sign * (point[axis]-value) >= -EPS
            if inside != prev_inside:
                delta = point[axis] - previous[axis]
                if abs(delta) > EPS:
                    ratio = (value - previous[axis]) / delta
                    cross = (previous[0]+ratio*(point[0]-previous[0]),
                             previous[1]+ratio*(point[1]-previous[1]))
                    result.append(cross)
            if inside:
                result.append(point)
            previous, prev_inside = point, inside
        points = dedupe(result)
    if len(points) > 2 and math.dist(points[0], points[-1]) < EPS:
        points.pop()
    area = abs(sum(a[0]*b[1]-b[0]*a[1] for a, b in zip(points, points[1:]+points[:1]))) / 2
    return points if len(points) >= 3 and area > EPS else []


def distance_to_segment(point, a, b):
    vx, vy = b[0]-a[0], b[1]-a[1]
    length_sq = vx*vx + vy*vy
    t = max(0, min(1, ((point[0]-a[0])*vx+(point[1]-a[1])*vy)/length_sq)) if length_sq else 0
    return math.hypot(point[0]-a[0]-t*vx, point[1]-a[1]-t*vy)


def rdp(points, tolerance):
    """Iterative RDP avoids recursion limits on detailed coast/lake outlines."""
    if len(points) < 3 or tolerance <= 0:
        return points
    keep, stack = {0, len(points)-1}, [(0, len(points)-1)]
    while stack:
        first, last = stack.pop()
        if last-first < 2:
            continue
        farthest = max(range(first+1, last), key=lambda i: distance_to_segment(points[i], points[first], points[last]))
        if distance_to_segment(points[farthest], points[first], points[last]) > tolerance:
            keep.add(farthest)
            stack.extend(((first, farthest), (farthest, last)))
    return [points[i] for i in sorted(keep)]


def simplify(points, closed, tolerance):
    if not closed:
        return rdp(points, tolerance)
    # Split a ring at a far point so identical first/last points cannot collapse it.
    pivot = max(range(1, len(points)), key=lambda i: math.dist(points[0], points[i]))
    result = rdp(points[:pivot+1], tolerance)[:-1] + rdp(points[pivot:]+points[:1], tolerance)[:-1]
    return result if len(result) >= 3 else points


def assemble_rings(chains):
    """Join OSM member ways by node IDs, allowing reversed member directions."""
    chains = [list(c) for c in chains if len(c) >= 2]
    rings, open_chains = [], []
    while chains:
        chain = chains.pop(0)
        changed = True
        while chain[0] != chain[-1] and changed:
            changed = False
            for index, candidate in enumerate(chains):
                if chain[-1] == candidate[0]:
                    chain.extend(candidate[1:])
                elif chain[-1] == candidate[-1]:
                    chain.extend(candidate[-2::-1])
                elif chain[0] == candidate[-1]:
                    chain = candidate[:-1]+chain
                elif chain[0] == candidate[0]:
                    chain = candidate[:0:-1]+chain
                else:
                    continue
                chains.pop(index)
                changed = True
                break
        if chain[0] == chain[-1] and len(set(chain)) >= 3:
            rings.append(chain)
        else:
            open_chains.append(chain)
    return rings, open_chains


def bbox_of(features):
    points = [p for feature in features for p in feature["points"]]
    return [min(p[0] for p in points), min(p[1] for p in points),
            max(p[0] for p in points), max(p[1] for p in points)]


def load_features(path, selected, project, stats):
    root = ET.parse(path).getroot()
    if root.tag != "osm":
        raise ValueError("Expected <osm> XML, not a web error page or another file format")
    nodes = {e.attrib["id"]: (float(e.attrib["lon"]), float(e.attrib["lat"])) for e in root.findall("node")}
    ways = {e.attrib["id"]: {"refs": [n.attrib["ref"] for n in e.findall("nd")], "tags": tags(e)} for e in root.findall("way")}
    relations = root.findall("relation")
    stats.update(source_nodes=len(nodes), source_ways=len(ways), source_relations=len(relations),
                 ignored_relations=[], incomplete_water_relations=[], missing_node_ways=[], unsupported_water_roles=[])
    features, water_members = [], set()

    def add(ident, name, layer, refs, closed):
        if not all(ref in nodes for ref in refs):
            stats["missing_node_ways"].append(ident)
            return
        points = dedupe([project(*nodes[ref]) for ref in refs])
        if closed and points and math.dist(points[0], points[-1]) < EPS:
            points.pop()
        if len(points) >= (3 if closed else 2):
            features.append(dict(id=ident, name=name, layer=layer, closed=closed, points=points))

    for relation in relations:
        t, ident = tags(relation), relation.attrib["id"]
        if "water" not in selected or t.get("type") != "multipolygon" or not is_water(t):
            stats["ignored_relations"].append(ident)
            continue
        role_chains = {"outer": [], "inner": []}
        missing = []
        for member in relation.findall("member"):
            role = member.attrib.get("role", "") or "outer"
            ref = member.attrib["ref"]
            if member.attrib.get("type") != "way" or role not in role_chains:
                stats["unsupported_water_roles"].append({"relation": ident, "type": member.attrib.get("type"), "role": role})
                continue
            if ref not in ways:
                missing.append(ref)
            else:
                role_chains[role].append(ways[ref]["refs"])
                water_members.add(ref)
        incomplete = {"relation": ident, "missing_members": missing, "open_outer_chains": 0, "open_inner_chains": 0}
        for role, chains in role_chains.items():
            rings, opens = assemble_rings(chains)
            incomplete[f"open_{role}_chains"] = len(opens)
            for index, refs in enumerate(rings):
                add(f"relation/{ident}/{role}/{index}", t.get("name", ""), "water" if role == "outer" else "islands", refs, True)
        if missing or incomplete["open_outer_chains"] or incomplete["open_inner_chains"]:
            stats["incomplete_water_relations"].append(incomplete)
    for ident, way in ways.items():
        t, refs = way["tags"], way["refs"]
        if len(refs) < 2:
            continue
        name = t.get("name", "")
        closed = refs[0] == refs[-1]
        if "water" in selected and ident not in water_members:
            if is_water(t) and closed:
                add(f"way/{ident}", name, "water", refs, True)
            elif t.get("waterway") in {"river", "stream", "canal", "drain", "ditch"}:
                add(f"way/{ident}", name, "water", refs, False)
        highway = t.get("highway")
        if highway and highway not in {"construction", "proposed"}:
            layer = "paths" if highway in PATH_TYPES else "roads"
            if layer in selected:
                add(f"way/{ident}", name, layer, refs, closed and len(refs) >= 4)
    return features


def write_dxf(path, features):
    rows = []
    def code(k, v):
        rows.extend((str(k), f"{v:.8f}" if isinstance(v, float) else str(v)))
    code(0, "SECTION"); code(2, "HEADER")
    code(9, "$ACADVER"); code(1, "AC1015")
    code(9, "$INSUNITS"); code(70, 4)
    code(9, "$MEASUREMENT"); code(70, 1)
    code(0, "ENDSEC"); code(0, "SECTION"); code(2, "TABLES")
    names = sorted({LAYER_NAMES[f["layer"]] for f in features})
    code(0, "TABLE"); code(2, "LAYER"); code(70, len(names))
    for index, name in enumerate(names):
        code(0, "LAYER"); code(100, "AcDbSymbolTableRecord"); code(100, "AcDbLayerTableRecord")
        code(2, name); code(70, 0); code(62, index % 6 + 1); code(6, "CONTINUOUS")
    code(0, "ENDTAB"); code(0, "ENDSEC"); code(0, "SECTION"); code(2, "ENTITIES")
    for feature in features:
        code(0, "LWPOLYLINE"); code(100, "AcDbEntity"); code(8, LAYER_NAMES[feature["layer"]])
        code(100, "AcDbPolyline"); code(90, len(feature["points"])); code(70, int(feature["closed"]))
        for x, y in feature["points"]:
            code(10, x); code(20, y)
    code(0, "ENDSEC"); code(0, "EOF")
    path.write_text("\n".join(rows)+"\n", encoding="ascii")
    # Read back the actual serialized file: validate every entity's layer/count/coordinates.
    tokens = path.read_text().splitlines()
    if len(tokens) % 2:
        raise ValueError("DXF group code/value imbalance")
    pairs = list(zip(tokens[::2], tokens[1::2]))
    count = 0
    for i, pair in enumerate(pairs):
        if pair != ("0", "LWPOLYLINE"):
            continue
        end = next((j for j in range(i+1, len(pairs)) if pairs[j][0] == "0"), len(pairs))
        entity = pairs[i+1:end]
        expected = next(int(v) for k, v in entity if k == "90")
        if not any(k == "8" and v in names for k, v in entity):
            raise ValueError("Missing DXF entity layer")
        xs, ys = [float(v) for k, v in entity if k == "10"], [float(v) for k, v in entity if k == "20"]
        if len(xs) != expected or len(ys) != expected or not all(math.isfinite(v) for v in xs+ys):
            raise ValueError("Invalid serialized DXF vertices")
        count += 1
    if count != len(features):
        raise ValueError("DXF entity count mismatch")


def write_svg(path, features, width, height, line_width):
    margin = 1.5
    colors = {"water": "#1685ae", "islands": "#1685ae", "roads": "#75818a", "paths": "#cf922b"}
    body = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width+2*margin}mm" height="{height+2*margin}mm" viewBox="{-width/2-margin} {-height/2-margin} {width+2*margin} {height+2*margin}">',
            '<rect x="-10000" y="-10000" width="20000" height="20000" fill="white"/>',
            f'<rect x="{-width/2}" y="{-height/2}" width="{width}" height="{height}" fill="none" stroke="#d9dfe3" stroke-width="0.08"/>',
            '<g transform="scale(1,-1)" fill="none" stroke-linecap="round" stroke-linejoin="round">']
    for feature in features:
        points = " ".join(f"{x:.6f},{y:.6f}" for x, y in feature["points"])
        element = "polygon" if feature["closed"] else "polyline"
        body.append(f'<{element} points="{points}" stroke="{colors[feature["layer"]]}" stroke-width="{line_width}"><title>{html.escape(feature["name"] or feature["id"])}</title></{element}>')
    body.extend(("</g>", "</svg>"))
    path.write_text("\n".join(body), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path, help="Complete OSM XML containing all referenced nodes/member ways")
    parser.add_argument("--bbox", required=True, type=float, nargs=4, metavar=("WEST", "SOUTH", "EAST", "NORTH"))
    parser.add_argument("--width-mm", required=True, type=float, help="Maximum artwork envelope width")
    parser.add_argument("--height-mm", required=True, type=float, help="Maximum artwork envelope height")
    parser.add_argument("--output-prefix", required=True, type=Path)
    parser.add_argument("--layers", default="water,roads,paths", help="Comma-separated water,roads,paths")
    parser.add_argument("--simplify-mm", type=float, default=0.035, help="Maximum RDP deviation in output mm; does not guarantee minimum gaps")
    parser.add_argument("--line-width-mm", type=float, default=0.18, help="SVG preview stroke only; set actual DXF import line width in EDA")
    args = parser.parse_args()
    west, south, east, north = args.bbox
    if not (-180 <= west < east <= 180 and -85 < south < north < 85):
        parser.error("bbox must be ordered west south east north; dateline-crossing is unsupported")
    if args.width_mm <= 0 or args.height_mm <= 0 or args.simplify_mm < 0 or args.line_width_mm <= 0:
        parser.error("dimensions/stroke must be positive and simplify-mm nonnegative")
    selected = set(args.layers.split(","))
    if not selected or not selected <= {"water", "roads", "paths"}:
        parser.error("layers must contain water, roads and/or paths")
    lon0, lat0 = (west+east)/2, (south+north)/2
    radius = 6371008.8
    factor_x = radius*math.pi/180*math.cos(math.radians(lat0))
    factor_y = radius*math.pi/180
    project = lambda lon, lat: ((lon-lon0)*factor_x, (lat-lat0)*factor_y)
    crop_box = (*project(west, south), *project(east, north))
    stats = {}
    original = load_features(args.input, selected, project, stats)
    clipped = []
    clipped_rings = 0
    for feature in original:
        points = feature["points"]
        if feature["closed"] and feature["layer"] in {"water", "islands"}:
            ring = clip_polygon(points, crop_box)
            parts = [ring] if ring else []
            if ring and any(not (crop_box[0]-EPS <= x <= crop_box[2]+EPS and crop_box[1]-EPS <= y <= crop_box[3]+EPS) for x, y in points):
                clipped_rings += 1
        else:
            # A closed highway is a boundary route, not a filled polygon.
            # Clipping it as an area invents roads along the crop rectangle.
            parts = clip_line(points + [points[0]] if feature["closed"] else points, crop_box)
        for index, part in enumerate(parts):
            closed = feature["closed"] and feature["layer"] in {"water", "islands"}
            if feature["layer"] in {"roads", "paths"}:
                closed = len(part) > 2 and math.dist(part[0], part[-1]) < EPS
                if closed:
                    part = part[:-1]
            clipped.append({**feature, "id": feature["id"]+f"/part/{index}", "points": part, "closed": closed})
    if not clipped:
        raise SystemExit("No selected complete map geometry intersects bbox; outputs not created")
    xmin, ymin, xmax, ymax = bbox_of(clipped)
    span_x, span_y = xmax-xmin, ymax-ymin
    if max(span_x, span_y) <= EPS:
        raise SystemExit("Selected geometry has no measurable extent")
    scale = min(args.width_mm/span_x if span_x > EPS else float("inf"),
                args.height_mm/span_y if span_y > EPS else float("inf"))
    cx, cy = (xmin+xmax)/2, (ymin+ymax)/2
    features = []
    for feature in clipped:
        points = [((x-cx)*scale, (y-cy)*scale) for x, y in feature["points"]]
        features.append({**feature, "points": simplify(points, feature["closed"], args.simplify_mm)})
    bounds = bbox_of(features)
    args.output_prefix.parent.mkdir(parents=True, exist_ok=True)
    dxf = args.output_prefix.with_suffix(".dxf")
    svg = args.output_prefix.with_suffix(".svg")
    report = args.output_prefix.with_suffix(".report.json")
    geojson = args.output_prefix.with_suffix(".geojson")
    write_dxf(dxf, features)
    write_svg(svg, features, args.width_mm, args.height_mm, args.line_width_mm)
    geographic = []
    for feature in features:
        coords = [[(x/scale+cx)/factor_x+lon0, (y/scale+cy)/factor_y+lat0] for x, y in feature["points"]]
        if feature["closed"] and feature["layer"] in {"water", "islands"}:
            geometry = {"type": "Polygon", "coordinates": [coords+[coords[0]]]}
        else:
            geometry = {"type": "LineString", "coordinates": coords+[coords[0]] if feature["closed"] else coords}
        # Island rings are separate Polygon features with role=inner; do not interpret as water fill.
        geographic.append({"type": "Feature", "properties": {"source_id": feature["id"], "name": feature["name"], "layer": feature["layer"], "role": "inner" if feature["layer"] == "islands" else "outer_or_line"}, "geometry": geometry})
    geojson.write_text(json.dumps({"type": "FeatureCollection", "features": geographic}, ensure_ascii=False), encoding="utf-8")
    warnings = ["DXF is graphical artwork without nets, components or board outline; assign layer and line width in EDA.",
                "Simplification controls deviation, not topology or minimum manufacturable line/space; compare map geometry and inspect final Gerber.",
                "Water islands are separate outline rings, not filled-water Boolean polygons."]
    if clipped_rings:
        warnings.append("Some water rings touch crop edges: clipping closes along rectangle edges; concave disconnected intersections are not split into independent polygons. Use bbox enclosing full lake for shoreline artwork.")
    if stats["missing_node_ways"] or stats["incomplete_water_relations"] or stats["unsupported_water_roles"]:
        warnings.append("Incomplete/unsupported OSM geometry was omitted; inspect diagnostics before import.")
    data = {"input": str(args.input.resolve()), "input_sha256": hashlib.sha256(args.input.read_bytes()).hexdigest(),
            "bbox_wsen": args.bbox, "projection": {"kind": "local_equirectangular", "origin_lon_lat": [lon0, lat0]},
            "requested_envelope_mm": [args.width_mm, args.height_mm], "actual_centerline_bbox_mm": bounds,
            "actual_centerline_size_mm": [bounds[2]-bounds[0], bounds[3]-bounds[1]], "mm_per_ground_metre": scale,
            "origin": "artwork bbox centre, x east/y north", "simplify_mm": args.simplify_mm,
            "preview_stroke_mm": args.line_width_mm, "source_feature_count": len(original), "output_entity_count": len(features),
            "output_vertex_count": sum(len(f["points"]) for f in features),
            "layer_entity_counts": dict(collections.Counter(LAYER_NAMES[f["layer"]] for f in features)),
            "clipped_polygon_ring_count": clipped_rings, "dxf_readback": "PASS", "diagnostics": stats,
            "warnings": warnings, "outputs": {"dxf": str(dxf), "svg": str(svg), "geojson": str(geojson)}}
    report.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"report": str(report), "entities": len(features), "size_mm": data["actual_centerline_size_mm"],
                      "dxf_readback": "PASS", "warnings": warnings}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
